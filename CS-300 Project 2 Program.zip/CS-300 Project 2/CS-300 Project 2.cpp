// CS-300 Project 2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <vector>
#include <algorithm>

using namespace std;

// Define the Course class
class Course {
public:
    string courseNumber;
    string courseTitle;
    vector<string> prerequisites;
};

// Declare the hash table
unordered_map<string, Course> courseTable;

// Convert string to uppercase
string toUpper(string str) {
    for (char& c : str) {
        c = toupper(c);
    }
    return str;
}

// Function to load courses from file
void loadCourses() {
    courseTable.clear(); // Clear existing data
    string fileName = "CS 300 ABCU_Advising_Program_Input.csv";

    ifstream file(fileName);
    if (!file.is_open()) {
        cout << "Error: File not found." << endl;
        return;
    }

    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        string token;
        vector<string> tokens;

        while (getline(ss, token, ',')) {
            tokens.push_back(token);
        }

        if (tokens.size() < 2) {
            cout << "Invalid line format." << endl;
            continue;
        }

        Course course;
        course.courseNumber = toUpper(tokens[0]);
        course.courseTitle = tokens[1];

        for (size_t i = 2; i < tokens.size(); ++i) {
            course.prerequisites.push_back(toUpper(tokens[i]));
        }

        courseTable[course.courseNumber] = course;
    }

    file.close();
    cout << "Courses loaded successfully." << endl;
}

// Function to print all courses sorted alphanumerically
void printCourseList() {
    if (courseTable.empty()) {
        cout << "Error: Load data first." << endl;
        return;
    }

    vector<string> keys;
    for (auto const& entry : courseTable) {
        keys.push_back(entry.first);
    }

    sort(keys.begin(), keys.end());

    cout << "Here is a sample schedule:" << endl;
    for (string key : keys) {
        cout << courseTable[key].courseNumber << ", " << courseTable[key].courseTitle << endl;
    }
}

// Function to search and print course information
void searchCourse() {
    if (courseTable.empty()) {
        cout << "Error: Load data first." << endl;
        return;
    }

    string courseNum;
    cout << "What course do you want to know about? ";
    cin >> courseNum;
    courseNum = toUpper(courseNum);

    if (courseTable.find(courseNum) == courseTable.end()) {
        cout << "Course not found." << endl;
        return;
    }

    Course course = courseTable[courseNum];
    cout << course.courseNumber << ", " << course.courseTitle << endl;

    if (!course.prerequisites.empty()) {
        cout << "Prerequisites: ";
        for (size_t i = 0; i < course.prerequisites.size(); ++i) {
            string prereq = course.prerequisites[i];
            cout << prereq;
            if (i < course.prerequisites.size() - 1) cout << ", ";
        }
        cout << endl;
    }
    else {
        cout << "Prerequisites: None" << endl;
    }
}

// Display the menu
void printMenu() {
    cout << "\n1. Load Data Structure." << endl;
    cout << "2. Print Course List." << endl;
    cout << "3. Print Course." << endl;
    cout << "9. Exit" << endl;
    cout << "What would you like to do? ";
}

// Main program
int main() {
    int choice = 0;
    bool dataLoaded = false;

    cout << "Welcome to the course planner." << endl;

    while (choice != 9) {
        printMenu();
        cin >> choice;

        switch (choice) {
        case 1:
            loadCourses();
            dataLoaded = true;
            break;
        case 2:
            printCourseList();
            break;
        case 3:
            searchCourse();
            break;
        case 9:
            cout << "Thank you for using the course planner!" << endl;
            break;
        default:
            cout << choice << " is not a valid option." << endl;
            break;
        }
    }

    return 0;
}